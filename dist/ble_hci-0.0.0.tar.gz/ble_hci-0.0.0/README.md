# ble_hci
Python3 BLE HCI Directed to MAX Vendor Specific Commands
